const namespace = "default";
export const namespaceURL = "namespaces/" + namespace;
