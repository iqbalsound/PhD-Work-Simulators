## API samples

These docs are examples of requests and responses of APIs.
